Strona z quizami

Cel? 

strona naukowa oparta na quizach w różnych dziedzinach nauki szkolnej ma pomoc w nauce/ urozmaicić ja/sprawic aby była ciekawsza i łatwo dostępna w każdym miejscu

Zasada? 

uczeń szkoły lub osoba prywatna wchodzi na stronę główną z której może się zalogować na konto, aby postępy były zapisywane, lub kontynuować bez logowania, aby sprawdzić czy strona w ogóle trafia do danego użytkownika.

Interakcja? 

podczas wykonywania quizu użytkownik losuje pytania z tablicy z pytaniami w JS dzięki guzikowi "losuj", a następnie wprowadza odpowiedź w okienko i ją sprawdza pod przyciskiem " sprawdź" który porównuje czy wprowadzona odpowiedź jest zgodna z odpowiedzia przypisaną do wylosowanego wcześniej pytania. Potem użytkownik może wylosować kolejne pytanie zadziała to na tej samej zasadzie jak za pierwszym razem z tym że poprzednia odpowiedź będzie oczywiście czyszczona aby zrobić miejsce na nową.
